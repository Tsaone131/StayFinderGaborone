package com.example.stayfindergaborone.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reservations")
data class Reservation(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val listingId: Int,
    val studentId: Int,
    val amountPaid: Double,
    val referenceNumber: String,
    val timestamp: Long = System.currentTimeMillis()
)