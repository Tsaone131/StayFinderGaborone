package com.example.stayfindergaborone.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [User::class, Listing::class, Message::class, Reservation::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun listingDao(): ListingDao
    abstract fun messageDao(): MessageDao
    abstract fun reservationDao(): ReservationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "stayfinder_database"
                )
                    .addCallback(AppDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    seedDatabase(database.listingDao())
                }
            }
        }

        suspend fun seedDatabase(listingDao: ListingDao) {
            if (listingDao.getListingCount() > 0) return

            val locations = listOf("Broadhurst", "Phase 2", "Tlokweng", "Gaborone West", "Main Mall")
            val types = listOf("Single Room", "1-Bedroom Flat", "Shared Studio", "Bedsitter", "Cottage")
            val amenitiesList = listOf("WiFi, Gated Wall", "Water Included, Near Bus Stop", "Aircon, Security", "WiFi, Laundry Room")
            val listings = ArrayList<Listing>()

            for (i in 1..50) {
                val loc = locations[i % locations.size]
                val type = types[i % types.size]
                val price = 1000.0 + (i * 45) % 2500 // Prices range dynamically across BWP 1000 - BWP 3500
                val deposit = price * 0.5
                val imageIndex = (i % 5) + 1 // Maps explicitly to house_1, house_2, house_3, house_4, house_5 drawables

                listings.add(
                    Listing(
                        title = "Comfortable $type $i",
                        priceBWP = price,
                        location = loc,
                        houseType = type,
                        amenities = amenitiesList[i % amenitiesList.size],
                        availabilityDate = "2026-06-01",
                        depositAmount = deposit,
                        imageResourceName = "house_$imageIndex"
                    )
                )
            }
            listingDao.insertAll(listings)
        }
    }
}