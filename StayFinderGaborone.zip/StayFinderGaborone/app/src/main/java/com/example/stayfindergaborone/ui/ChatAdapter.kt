package com.example.stayfindergaborone.ui

import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.stayfindergaborone.R
import com.example.stayfindergaborone.data.Message
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatAdapter(
    private var messages: List<Message>,
    private val currentUserId: Int
) : RecyclerView.Adapter<ChatAdapter.MessageViewHolder>() {

    inner class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvContent: TextView = itemView.findViewById(R.id.tvMessageContent)
        val tvTime: TextView = itemView.findViewById(R.id.tvMessageTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_message, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = messages[position]
        holder.tvContent.text = message.content

        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        holder.tvTime.text = timeFormat.format(Date(message.timestamp))

        val container = holder.itemView as LinearLayout

        if (message.senderId == currentUserId) {
            container.gravity = Gravity.END
            holder.tvContent.setBackgroundResource(R.drawable.bg_message_sent)
            holder.tvContent.setTextColor(
                holder.itemView.context.getColor(R.color.white)
            )
            holder.tvTime.gravity = Gravity.END
        } else {
            container.gravity = Gravity.START
            holder.tvContent.setBackgroundResource(R.drawable.bg_message_received)
            holder.tvContent.setTextColor(
                holder.itemView.context.getColor(R.color.text_primary)
            )
            holder.tvTime.gravity = Gravity.START
        }
    }

    override fun getItemCount() = messages.size

    fun updateMessages(newMessages: List<Message>) {
        messages = newMessages
        notifyDataSetChanged()
    }
}