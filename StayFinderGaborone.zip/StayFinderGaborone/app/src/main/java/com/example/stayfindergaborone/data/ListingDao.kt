package com.example.stayfindergaborone.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ListingDao {
    @Query("SELECT * FROM listings WHERE isReserved = 0")
    suspend fun getAllAvailableListings(): List<Listing>

    @Query("""
        SELECT * FROM listings 
        WHERE isReserved = 0 
        AND priceBWP >= :minPrice 
        AND priceBWP <= :maxPrice 
        AND (:location = 'All' OR location = :location)
    """)
    suspend fun filterListings(minPrice: Double, maxPrice: Double, location: String): List<Listing>

    @Query("SELECT * FROM listings WHERE id = :id")
    suspend fun getListingById(id: Int): Listing?

    @Query("UPDATE listings SET isReserved = 1, reservedByUserId = :userId, paymentReference = :payRef WHERE id = :listingId")
    suspend fun reserveListing(listingId: Int, userId: Int, payRef: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(listings: List<Listing>)

    @Query("SELECT COUNT(*) FROM listings")
    suspend fun getListingCount(): Int
}