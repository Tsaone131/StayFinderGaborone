package com.example.stayfindergaborone.ui

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.stayfindergaborone.MainActivity
import com.example.stayfindergaborone.R
import com.example.stayfindergaborone.SessionManager
import com.example.stayfindergaborone.data.AppDatabase
import com.example.stayfindergaborone.data.User
import com.example.stayfindergaborone.repository.AccommoRepository
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {

    private lateinit var repository: AccommoRepository
    private lateinit var tilStudentId: TextInputLayout
    private lateinit var tilFullName: TextInputLayout
    private lateinit var tilEmail: TextInputLayout
    private lateinit var tilPassword: TextInputLayout
    private lateinit var tilConfirmPassword: TextInputLayout
    private lateinit var etStudentId: TextInputEditText
    private lateinit var etFullName: TextInputEditText
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var etConfirmPassword: TextInputEditText
    private lateinit var btnRegister: MaterialButton
    private lateinit var tvLogin: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val db = AppDatabase.getDatabase(this)
        repository = AccommoRepository(db)

        tilStudentId = findViewById(R.id.tilStudentId)
        tilFullName = findViewById(R.id.tilFullName)
        tilEmail = findViewById(R.id.tilEmail)
        tilPassword = findViewById(R.id.tilPassword)
        tilConfirmPassword = findViewById(R.id.tilConfirmPassword)
        etStudentId = findViewById(R.id.etStudentId)
        etFullName = findViewById(R.id.etFullName)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnRegister = findViewById(R.id.btnRegister)
        tvLogin = findViewById(R.id.tvLogin)

        btnRegister.setOnClickListener {
            val studentId = etStudentId.text.toString().trim()
            val fullName = etFullName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val confirmPassword = etConfirmPassword.text.toString().trim()

            var isValid = true

            if (studentId.isEmpty()) {
                tilStudentId.error = "Student ID is required"
                isValid = false
            } else {
                tilStudentId.error = null
            }

            if (fullName.isEmpty()) {
                tilFullName.error = "Full name is required"
                isValid = false
            } else {
                tilFullName.error = null
            }

            if (email.isEmpty()) {
                tilEmail.error = "Email is required"
                isValid = false
            } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                tilEmail.error = "Enter a valid email"
                isValid = false
            } else {
                tilEmail.error = null
            }

            if (password.isEmpty()) {
                tilPassword.error = "Password is required"
                isValid = false
            } else if (password.length < 6) {
                tilPassword.error = "Password must be at least 6 characters"
                isValid = false
            } else {
                tilPassword.error = null
            }

            if (confirmPassword != password) {
                tilConfirmPassword.error = "Passwords do not match"
                isValid = false
            } else {
                tilConfirmPassword.error = null
            }

            if (isValid) {
                lifecycleScope.launch {
                    // Check if email already exists
                    val existing = repository.getUserByEmail(email)
                    if (existing != null) {
                        runOnUiThread {
                            tilEmail.error = "Email already registered"
                        }
                        return@launch
                    }

                    val userId = repository.register(
                        User(
                            studentId = studentId,
                            fullName = fullName,
                            email = email,
                            password = password,
                            role = "student"
                        )
                    )

                    SessionManager.saveSession(
                        this@RegisterActivity,
                        userId.toInt(),
                        fullName,
                        "student"
                    )

                    runOnUiThread {
                        Toast.makeText(
                            this@RegisterActivity,
                            "Account created! Welcome, $fullName!",
                            Toast.LENGTH_SHORT
                        ).show()
                        startActivity(Intent(this@RegisterActivity, HomeActivity::class.java))
                        finish()
                    }
                }
            }
        }

        tvLogin.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}