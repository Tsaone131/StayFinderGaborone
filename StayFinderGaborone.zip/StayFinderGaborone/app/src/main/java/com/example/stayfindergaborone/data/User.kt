package com.example.stayfindergaborone.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val studentId: String,
    val fullName: String,
    val email: String,
    val password: String,
    val role: String = "student"
)