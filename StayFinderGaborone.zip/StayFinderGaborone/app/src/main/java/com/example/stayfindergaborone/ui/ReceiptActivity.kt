package com.example.stayfindergaborone.ui

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.stayfindergaborone.R
import com.google.android.material.button.MaterialButton
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReceiptActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receipt)

        // Get data from PaymentActivity
        val referenceNumber = intent.getStringExtra("REFERENCE_NUMBER") ?: ""
        val listingTitle = intent.getStringExtra("LISTING_TITLE") ?: ""
        val amountPaid = intent.getDoubleExtra("AMOUNT_PAID", 0.0)
        val studentName = intent.getStringExtra("STUDENT_NAME") ?: ""

        // Views
        val tvReferenceNumber = findViewById<TextView>(R.id.tvReferenceNumber)
        val tvReceiptStudentName = findViewById<TextView>(R.id.tvReceiptStudentName)
        val tvReceiptListing = findViewById<TextView>(R.id.tvReceiptListing)
        val tvReceiptAmount = findViewById<TextView>(R.id.tvReceiptAmount)
        val tvReceiptDate = findViewById<TextView>(R.id.tvReceiptDate)
        val btnBackToHome = findViewById<MaterialButton>(R.id.btnBackToHome)

        // Fill in receipt details
        tvReferenceNumber.text = referenceNumber
        tvReceiptStudentName.text = studentName
        tvReceiptListing.text = listingTitle
        tvReceiptAmount.text = "BWP ${String.format("%,.0f", amountPaid)}"

        // Format current date
        val dateFormat = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale.getDefault())
        tvReceiptDate.text = dateFormat.format(Date())

        // Back to Home — clear the whole back stack
        btnBackToHome.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()
        }
    }
}