package com.example.stayfindergaborone.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.stayfindergaborone.R
import com.example.stayfindergaborone.data.Listing

class ListingAdapter(
    private var listings: List<Listing>,
    private val onItemClick: (Listing) -> Unit
) : RecyclerView.Adapter<ListingAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgHouse: ImageView = view.findViewById(R.id.imgHouse)
        val txtTitle: TextView = view.findViewById(R.id.txtTitle)
        val txtLocation: TextView = view.findViewById(R.id.txtLocation)
        val txtPrice: TextView = view.findViewById(R.id.txtPrice)
        val txtType: TextView = view.findViewById(R.id.txtType)
        val txtStatus: TextView = view.findViewById(R.id.txtStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_listing, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = listings[position]

        // Match these exactly with the properties inside Listing.kt
        holder.txtTitle.text = item.title
        holder.txtLocation.text = item.location
        holder.txtType.text = item.houseType
        holder.txtPrice.text = "BWP ${item.priceBWP}/month"
        holder.txtStatus.text = if (item.isReserved) "Reserved" else "Available"

        // Dynamically find image inside res/drawable using imageResourceName string
        val context = holder.itemView.context
        val resId = context.resources.getIdentifier(item.imageResourceName, "drawable", context.packageName)
        if (resId != 0) {
            holder.imgHouse.setImageResource(resId)
        } else {
            holder.imgHouse.setImageResource(android.R.drawable.ic_menu_gallery)
        }

        holder.itemView.setOnClickListener { onItemClick(item) }
    }

    override fun getItemCount() = listings.size

    fun updateData(newList: List<Listing>) {
        this.listings = newList
        notifyDataSetChanged()
    }
}