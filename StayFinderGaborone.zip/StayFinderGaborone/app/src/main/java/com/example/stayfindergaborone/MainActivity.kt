
package com.example.stayfindergaborone

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.stayfindergaborone.data.AppDatabase
import com.example.stayfindergaborone.repository.AccommoRepository
import com.example.stayfindergaborone.ui.HomeActivity
import com.example.stayfindergaborone.ui.RegisterActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var repository: AccommoRepository
    private lateinit var tilEmail: TextInputLayout
    private lateinit var tilPassword: TextInputLayout
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var btnLogin: MaterialButton
    private lateinit var tvRegister: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // If already logged in go straight to Home
        if (SessionManager.isLoggedIn(this)) {
            goToHome()
            return
        }

        setContentView(R.layout.activity_main)

        val db = AppDatabase.getDatabase(this)
        repository = AccommoRepository(db)

        tilEmail = findViewById(R.id.tilEmail)
        tilPassword = findViewById(R.id.tilPassword)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        tvRegister = findViewById(R.id.tvRegister)

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            var isValid = true

            if (email.isEmpty()) {
                tilEmail.error = "Email is required"
                isValid = false
            } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                tilEmail.error = "Enter a valid email"
                isValid = false
            } else {
                tilEmail.error = null
            }

            if (password.isEmpty()) {
                tilPassword.error = "Password is required"
                isValid = false
            } else if (password.length < 6) {
                tilPassword.error = "Password must be at least 6 characters"
                isValid = false
            } else {
                tilPassword.error = null
            }

            if (isValid) {
                lifecycleScope.launch {
                    val user = repository.login(email, password)
                    if (user != null) {
                        SessionManager.saveSession(
                            this@MainActivity,
                            user.id,
                            user.fullName,
                            user.role
                        )
                        runOnUiThread {
                            Toast.makeText(
                                this@MainActivity,
                                "Welcome back, ${user.fullName}!",
                                Toast.LENGTH_SHORT
                            ).show()
                            goToHome()
                        }
                    } else {
                        runOnUiThread {
                            tilPassword.error = "Invalid email or password"
                        }
                    }
                }
            }
        }

        tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun goToHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}