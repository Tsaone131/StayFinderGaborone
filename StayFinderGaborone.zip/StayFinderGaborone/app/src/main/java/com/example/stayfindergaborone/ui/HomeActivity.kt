package com.example.stayfindergaborone.ui

import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.stayfindergaborone.R
import com.example.stayfindergaborone.data.AppDatabase
import com.example.stayfindergaborone.data.Listing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var adapter: ListingAdapter
    private lateinit var notificationHelper: NotificationHelper
    private var maxPriceSelected: Double = 3500.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        db = AppDatabase.getDatabase(this, lifecycleScope)
        notificationHelper = NotificationHelper(this)

        val spinnerLocation = findViewById<Spinner>(R.id.spinnerLocation)
        val seekBarMaxPrice = findViewById<SeekBar>(R.id.seekBarMaxPrice)
        val txtPriceLabel = findViewById<TextView>(R.id.txtPriceLabel)
        val btnApplyFilters = findViewById<Button>(R.id.btnApplyFilters)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewListings)

        recyclerView.layoutManager = LinearLayoutManager(this)

        // Sync seekbar adjustments dynamically onto your text layout indicator
        seekBarMaxPrice.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val evaluatedPrice = if (progress < 1000) 1000 else progress
                maxPriceSelected = evaluatedPrice.toDouble()
                txtPriceLabel.text = "Maximum Price Limit: BWP $evaluatedPrice"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnApplyFilters.setOnClickListener {
            val selectedLocation = spinnerLocation.selectedItem.toString()

            lifecycleScope.launch(Dispatchers.IO) {
                val matchedResults = db.listingDao().filterListings(0.0, maxPriceSelected, selectedLocation)

                withContext(Dispatchers.Main) {
                    adapter.updateData(matchedResults)
                    if (matchedResults.isNotEmpty()) {
                        notificationHelper.triggerMatchNotification(selectedLocation, maxPriceSelected)
                    }
                }
            }
        }

        // Initial background data load to fill your view matrix container
        lifecycleScope.launch(Dispatchers.IO) {
            val listings = db.listingDao().getAllAvailableListings()
            withContext(Dispatchers.Main) {
                adapter = ListingAdapter(listings) { selectedListing ->
                    // Navigation routing code for detail view goes here
                }
                recyclerView.adapter = adapter
            }
        }
    }
}