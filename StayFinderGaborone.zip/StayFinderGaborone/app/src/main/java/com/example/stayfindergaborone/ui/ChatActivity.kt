package com.example.stayfindergaborone.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.stayfindergaborone.R
import com.example.stayfindergaborone.SessionManager
import com.example.stayfindergaborone.data.AppDatabase
import com.example.stayfindergaborone.data.Message
import com.example.stayfindergaborone.repository.AccommoRepository
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class ChatActivity : AppCompatActivity() {

    private lateinit var repository: AccommoRepository
    private lateinit var adapter: ChatAdapter
    private var listingId: Int = -1
    private var landlordId: Int = -1
    private var currentUserId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        val db = AppDatabase.getDatabase(this)
        repository = AccommoRepository(db)

        listingId = intent.getIntExtra("LISTING_ID", -1)
        landlordId = intent.getIntExtra("LANDLORD_ID", -1)
        currentUserId = SessionManager.getUserId(this)

        // Toolbar
        val toolbar = findViewById<Toolbar>(R.id.chatToolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        // RecyclerView
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewMessages)
        adapter = ChatAdapter(emptyList(), currentUserId)
        val layoutManager = LinearLayoutManager(this)
        layoutManager.stackFromEnd = true
        recyclerView.layoutManager = layoutManager
        recyclerView.adapter = adapter

        // Observe messages
        repository.getMessages(listingId, currentUserId).observe(this) { messages ->
            adapter.updateMessages(messages)
            if (messages.isNotEmpty()) {
                recyclerView.scrollToPosition(messages.size - 1)
            }
        }

        // Send message
        val etMessage = findViewById<TextInputEditText>(R.id.etMessage)
        val btnSend = findViewById<MaterialButton>(R.id.btnSend)

        btnSend.setOnClickListener {
            val content = etMessage.text.toString().trim()
            if (content.isEmpty()) {
                Toast.makeText(this, "Type a message first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                repository.sendMessage(
                    Message(
                        listingId = listingId,
                        senderId = currentUserId,
                        receiverId = landlordId,
                        content = content
                    )
                )
                runOnUiThread {
                    etMessage.setText("")
                }
            }
        }
    }
}