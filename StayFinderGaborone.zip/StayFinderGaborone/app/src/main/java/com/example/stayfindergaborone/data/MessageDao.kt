package com.example.stayfindergaborone.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface MessageDao {
    @Insert
    suspend fun insert(message: Message)

    @Query("""
        SELECT * FROM messages 
        WHERE listingId = :listingId 
        AND ((senderId = :userId) OR (receiverId = :userId))
        ORDER BY timestamp ASC
    """)
    fun getMessages(listingId: Int, userId: Int): LiveData<List<Message>>
}