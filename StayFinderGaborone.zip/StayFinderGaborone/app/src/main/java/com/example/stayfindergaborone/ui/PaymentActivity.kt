package com.example.stayfindergaborone.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.stayfindergaborone.R
import com.example.stayfindergaborone.SessionManager
import com.example.stayfindergaborone.data.AppDatabase
import com.example.stayfindergaborone.data.Reservation
import com.example.stayfindergaborone.repository.AccommoRepository
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.launch

class PaymentActivity : AppCompatActivity() {

    private lateinit var repository: AccommoRepository
    private var depositAmount: Double = 0.0
    private var listingId: Int = -1
    private var listingTitle: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        val db = AppDatabase.getDatabase(this)
        repository = AccommoRepository(db)

        // Get data passed from ListingDetailActivity
        listingId = intent.getIntExtra("LISTING_ID", -1)
        listingTitle = intent.getStringExtra("LISTING_TITLE") ?: ""
        depositAmount = intent.getDoubleExtra("DEPOSIT_AMOUNT", 0.0)

        // Views
        val tvPaymentTitle = findViewById<TextView>(R.id.tvPaymentTitle)
        val tvDepositRequired = findViewById<TextView>(R.id.tvDepositRequired)
        val tilAmount = findViewById<TextInputLayout>(R.id.tilAmount)
        val etAmount = findViewById<TextInputEditText>(R.id.etAmount)
        val tvAmountFeedback = findViewById<TextView>(R.id.tvAmountFeedback)
        val btnConfirmPayment = findViewById<MaterialButton>(R.id.btnConfirmPayment)
        val btnCancelPayment = findViewById<MaterialButton>(R.id.btnCancelPayment)

        // Display listing info
        tvPaymentTitle.text = listingTitle
        tvDepositRequired.text = "BWP ${String.format("%,.0f", depositAmount)}"

        // Real-time feedback as user types amount
        etAmount.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val input = s.toString().trim()
                if (input.isEmpty()) {
                    tvAmountFeedback.visibility = android.view.View.GONE
                    tilAmount.error = null
                    return
                }

                val enteredAmount = input.toDoubleOrNull()
                if (enteredAmount == null) {
                    tvAmountFeedback.visibility = android.view.View.VISIBLE
                    tvAmountFeedback.text = "❌ Please enter a valid number"
                    tvAmountFeedback.setTextColor(getColor(R.color.reserved_red))
                    return
                }

                tvAmountFeedback.visibility = android.view.View.VISIBLE

                when {
                    enteredAmount == depositAmount -> {
                        // Exact match
                        tvAmountFeedback.text = "✅ Amount matches! You're good to go."
                        tvAmountFeedback.setTextColor(getColor(R.color.available_green))
                        tilAmount.error = null
                        tilAmount.boxStrokeColor = getColor(R.color.available_green)
                    }
                    enteredAmount < depositAmount -> {
                        // Too low
                        val shortfall = depositAmount - enteredAmount
                        tvAmountFeedback.text = "❌ Amount too low. You need BWP ${String.format("%,.0f", shortfall)} more."
                        tvAmountFeedback.setTextColor(getColor(R.color.reserved_red))
                        tilAmount.boxStrokeColor = getColor(R.color.reserved_red)
                    }
                    else -> {
                        // Too high
                        val excess = enteredAmount - depositAmount
                        tvAmountFeedback.text = "❌ Amount too high. You entered BWP ${String.format("%,.0f", excess)} extra."
                        tvAmountFeedback.setTextColor(getColor(R.color.reserved_red))
                        tilAmount.boxStrokeColor = getColor(R.color.reserved_red)
                    }
                }
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        // Confirm Payment
        btnConfirmPayment.setOnClickListener {
            val input = etAmount.text.toString().trim()

            if (input.isEmpty()) {
                tilAmount.error = "Please enter an amount"
                return@setOnClickListener
            }

            val enteredAmount = input.toDoubleOrNull()
            if (enteredAmount == null) {
                tilAmount.error = "Invalid amount"
                return@setOnClickListener
            }

            // Check exact match
            if (enteredAmount != depositAmount) {
                tilAmount.error = "Amount must exactly match the deposit: BWP ${String.format("%,.0f", depositAmount)}"
                return@setOnClickListener
            }

            // Amount matches — process reservation
            lifecycleScope.launch {
                // Check not already reserved
                val existing = repository.getReservationByListing(listingId)
                if (existing != null) {
                    runOnUiThread {
                        tilAmount.error = "This listing is already reserved"
                    }
                    return@launch
                }

                // Generate reference number
                val referenceNumber = "SF-${System.currentTimeMillis().toString().takeLast(8)}"

                // Save reservation
                val reservation = Reservation(
                    listingId = listingId,
                    studentId = SessionManager.getUserId(this@PaymentActivity),
                    amountPaid = enteredAmount,
                    referenceNumber = referenceNumber
                )
                repository.makeReservation(reservation)

                // Update listing status to Reserved
                repository.updateListingStatus(listingId, "Reserved")

                // Go to Receipt screen
                runOnUiThread {
                    val intent = Intent(this@PaymentActivity, ReceiptActivity::class.java)
                    intent.putExtra("REFERENCE_NUMBER", referenceNumber)
                    intent.putExtra("LISTING_TITLE", listingTitle)
                    intent.putExtra("AMOUNT_PAID", enteredAmount)
                    intent.putExtra("STUDENT_NAME", SessionManager.getUserName(this@PaymentActivity))
                    startActivity(intent)
                    finish()
                }
            }
        }

        btnCancelPayment.setOnClickListener {
            finish()
        }
    }
}