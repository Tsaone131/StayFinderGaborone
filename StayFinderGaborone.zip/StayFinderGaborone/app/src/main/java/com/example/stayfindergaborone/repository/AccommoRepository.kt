package com.example.stayfindergaborone.repository

import androidx.lifecycle.LiveData
import com.example.stayfindergaborone.data.*

class AccommoRepository(private val db: AppDatabase) {

    private val userDao = db.userDao()
    private val listingDao = db.listingDao()
    private val reservationDao = db.reservationDao()
    private val messageDao = db.messageDao()

    // Users
    suspend fun register(user: User): Long = userDao.insert(user)
    suspend fun login(email: String, password: String): User? = userDao.login(email, password)
    suspend fun getUserByEmail(email: String): User? = userDao.getUserByEmail(email)
    suspend fun getUserById(id: Int): User? = userDao.getUserById(id)
    suspend fun getAllLandlords(): List<User> = userDao.getAllLandlords()

    // Listings
    fun getAllListings(): LiveData<List<Listing>> = listingDao.getAllListings()
    fun getAvailableListings(): LiveData<List<Listing>> = listingDao.getAvailableListings()
    fun filterByDate(date: String): LiveData<List<Listing>> = listingDao.filterByDate(date)
    suspend fun getListingById(id: Int): Listing? = listingDao.getListingById(id)
    suspend fun updateListingStatus(id: Int, status: String) = listingDao.updateStatus(id, status)

    // Reservations
    suspend fun makeReservation(reservation: Reservation) = reservationDao.insert(reservation)
    suspend fun getReservationByListing(listingId: Int): Reservation? = reservationDao.getByListing(listingId)
    suspend fun getReservationsByStudent(studentId: Int): List<Reservation> = reservationDao.getByStudent(studentId)

    // Messages
    suspend fun sendMessage(message: Message) = messageDao.insert(message)
    fun getMessages(listingId: Int, userId: Int): LiveData<List<Message>> =
        messageDao.getMessages(listingId, userId)
}