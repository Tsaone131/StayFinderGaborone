package com.example.stayfindergaborone.data

import androidx.room.*

@Dao
interface ReservationDao {
    @Insert
    suspend fun insert(reservation: Reservation)

    @Query("SELECT * FROM reservations WHERE listingId = :listingId LIMIT 1")
    suspend fun getByListing(listingId: Int): Reservation?

    @Query("SELECT * FROM reservations WHERE studentId = :studentId")
    suspend fun getByStudent(studentId: Int): List<Reservation>
}