package com.example.stayfindergaborone.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "listings")
data class Listing(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val priceBWP: Double,
    val location: String, // Broadhurst, Phase 2, Tlokweng, etc.
    val houseType: String,
    val amenities: String,
    val availabilityDate: String, // YYYY-MM-DD format
    val depositAmount: Double,
    val imageResourceName: String, // e.g., "house_1", "house_2"
    val isReserved: Boolean = false,
    val reservedByUserId: Int? = null,
    val paymentReference: String? = null
)