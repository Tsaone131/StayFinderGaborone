package com.example.stayfindergaborone.ui

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.stayfindergaborone.R
import com.example.stayfindergaborone.data.AppDatabase
import com.example.stayfindergaborone.data.Listing
import com.example.stayfindergaborone.repository.AccommoRepository
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

class ListingDetailActivity : AppCompatActivity() {

    private lateinit var repository: AccommoRepository
    private var currentListing: Listing? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listing_detail)

        val db = AppDatabase.getDatabase(this)
        repository = AccommoRepository(db)

        val listingId = intent.getIntExtra("LISTING_ID", -1)
        if (listingId == -1) {
            finish()
            return
        }

        // Views
        val imgDetail = findViewById<ImageView>(R.id.imgDetail)
        val tvDetailTitle = findViewById<TextView>(R.id.tvDetailTitle)
        val tvDetailStatus = findViewById<TextView>(R.id.tvDetailStatus)
        val tvDetailLocation = findViewById<TextView>(R.id.tvDetailLocation)
        val tvDetailType = findViewById<TextView>(R.id.tvDetailType)
        val tvDetailDate = findViewById<TextView>(R.id.tvDetailDate)
        val tvDetailAmenities = findViewById<TextView>(R.id.tvDetailAmenities)
        val tvDetailPrice = findViewById<TextView>(R.id.tvDetailPrice)
        val tvDetailDeposit = findViewById<TextView>(R.id.tvDetailDeposit)
        val btnReserve = findViewById<MaterialButton>(R.id.btnReserve)
        val btnBack = findViewById<MaterialButton>(R.id.btnBack)
        val btnChat = findViewById<MaterialButton>(R.id.btnChat)

        btnBack.setOnClickListener { finish() }
        btnChat.setOnClickListener {
            val intent = Intent(this@ListingDetailActivity, ChatActivity::class.java)
            intent.putExtra("LISTING_ID", currentListing!!.id)
            intent.putExtra("LANDLORD_ID", currentListing!!.landlordId)
            startActivity(intent)
        }

        lifecycleScope.launch {
            val listing = repository.getListingById(listingId)
            listing?.let {
                currentListing = it
                runOnUiThread {
                    tvDetailTitle.text = it.title
                    tvDetailLocation.text = "📍 ${it.location}"
                    tvDetailType.text = "🏠 ${it.type}"
                    tvDetailDate.text = "📅 Available from: ${it.availabilityDate}"
                    tvDetailAmenities.text = it.amenities
                    tvDetailPrice.text = "BWP ${String.format("%,.0f", it.price)}"
                    tvDetailDeposit.text = "BWP ${String.format("%,.0f", it.depositAmount)}"

                    // Image
                    val imageRes = when (it.imageResName) {
                        "house_1" -> R.drawable.house_1
                        "house_2" -> R.drawable.house_2
                        "house_3" -> R.drawable.house_3
                        "house_4" -> R.drawable.house_4
                        "house_5" -> R.drawable.house_5
                        else -> R.drawable.ic_home
                    }
                    imgDetail.setImageResource(imageRes)

                    // Status
                    if (it.status == "Reserved") {
                        tvDetailStatus.text = "Reserved"
                        tvDetailStatus.setBackgroundResource(R.drawable.bg_status_reserved)
                        btnReserve.isEnabled = false
                        btnReserve.text = "ALREADY RESERVED"
                        btnReserve.alpha = 0.5f
                    } else {
                        tvDetailStatus.text = "Available"
                        tvDetailStatus.setBackgroundResource(R.drawable.bg_status_badge)
                        btnReserve.isEnabled = true
                        btnReserve.text = "RESERVE THIS PLACE"
                        btnReserve.alpha = 1.0f
                    }

                    // Reserve button → go to payment screen
                    val btnReserve = findViewById<MaterialButton>(R.id.btnReserve)
                    btnReserve.setOnClickListener {
                        val intent = Intent(
                            this@ListingDetailActivity,
                            PaymentActivity::class.java
                        )
                        intent.putExtra("LISTING_ID", currentListing!!.id)
                        intent.putExtra("LISTING_TITLE", currentListing!!.title)
                        intent.putExtra("DEPOSIT_AMOUNT", currentListing!!.depositAmount)
                        startActivity(intent)
                    }
                }
            } ?: runOnUiThread {
                Toast.makeText(this@ListingDetailActivity, "Listing not found", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}