package com.example.stayfindergaborone.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val listingId: Int,
    val senderId: Int,
    val receiverId: Int,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)